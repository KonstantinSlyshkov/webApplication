#!/usr/bin/env bash

# Vars
######################################################################

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
CONTINUE_TEXT="Enter [C] to continue when you're done with this."
INSTALL_PROXY=false

G="\\033[1;32m" #Green
B="\\033[1;34m" #Blue
N="\\033[0;39m" #Back to normal


# Functions
######################################################################

function e {
	echo -e $1
}

function ok_continue {
	echo $CONTINUE_TEXT; read mot
	while [[ $mot != "C" && $mot != "c" ]]; do
		echo $CONTINUE_TEXT; read mot
	done
}

# Install
######################################################################
clear
e $B
e "------------------------------------------------"
e " Swissquote Base script"
e "------------------------------------------------"
e
e "Welcome to the base installation script. we'll guide you through the steps."
e $N


# Proxy
e 'Do you want to configure the proxy ? (if yes: [Y] and [enter])'
read answer
if [[ $answer = "Y" || $answer = "y" ]]; then
	INSTALL_PROXY=true
	
	bash $DIR/cntlm.sh || exit $?
fi

# We should have the network at this point; update
echo -e "$G--- apt-get update$N"
APT_GET=$(sudo apt-get update)	
if echo $APT_GET | grep -q "Err" ; then
	echo "apt-get update Failed"
	exit 1
fi


# RBENV + Git
bash $DIR/ruby.sh || exit $?


# source the file again for the current process
source ~/.bash_aliases


# Mercurial
bash $DIR/mercurial.sh || exit $?
ok_continue


# Chef + Vagrant
bash $DIR/chef.sh || exit $?


# Next Steps
######################################################################

# Doc
clear
e $B

e "------------------------------------------------"
e " What did you do to my computer ?"
e "------------------------------------------------"
e "\nInstalled programs:"
if [[ $INSTALL_PROXY = true ]]; then
	e "- cntlm"
fi
e "- git"
e "- ruby (with rbenv)"
e "- mercurial"
e "- chef"
e "- vagrant"

e "\nConfigurations:"
if [[ $INSTALL_PROXY = true ]]; then
	e "- proxy configurations for GEM, CURL, APT, WGET, GIT"
fi
e "- mercurial configuration"

e "\n"

e "------------------------------------------------"
e " Next Steps"
e "------------------------------------------------"
e "\n"
e "!!! Run this command: 'source ~/.bash_aliases' !!!"

e "\nProxy:"
e " - Configure your applications to use the proxy at 127.0.0.1:3129 (HTTP and HTTPS)"
e " - Check that the mirrors have been updated in /etc/apt/sources.list"

e "\nChef:"
e " You can now launch the chef commands:"
e "->  cd /work/foundation/sq-sandbox/devops "
e "->  ls json/*.json "
e " Then you can choose a script and run it with:"
e "->  ./localprovision.sh json/dev-XXX.json "

e $N
