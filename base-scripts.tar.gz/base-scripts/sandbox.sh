#!/bin/ksh

export JAVA_HOME="/usr/lib/jvm/jdk1.7.0_09/bin/java"
export PATH="$PATH:/usr/lib/jvm/jdk1.7.0_09/bin"
export PATH="$PATH:$HOME/.rbenv/bin"
export PATH="$PATH:$HOME/.rbenv/shims"

ERROR='\033[0;31m'
INFO='\033[0;00m'
PURPLE='\033[0;35m'
YELLOW='\033[0;33m'

while getopts "s:r:m:p:f:" opt;
do
        case $opt
        in
                s) source=${OPTARG};;
                m) machine=${OPTARG};;
                p) password=${OPTARG};;
                r) restart="true";;
                f) force="true";;
		:) ;;
        esac
done

DIR="$( cd "$( dirname "$0" )" && pwd )";

echo -e "${INFO}Running sandbox provisioning script..."
echo -e "=========== Parameters ==================\n"
echo "source = ${source}"
echo "virtual machine = ${machine}"
echo "restart VM = ${restart}"
echo "force = ${force}"
echo -e "\n======== End of Parameters ==============\n"

if [[ -z $source ]]
then
  echo "${ERROR}Error. 'sq-sandbox' path is not specified. Please use '-s' option to set it up${INFO}"
  exit;
fi

cd /$source;

echo -e "Check 'sq-sandbox' for latest changesets\n"

hg in --template '{date|isodate} - {rev} - {author} - {desc}\n';
retCode=$?;

if [[ $retCode != 1 || ! -z $force ]]
then
        echo -e "[sq-sandbox] Update with latest changests"
        hg pull --update;

        cd /$source/devops/virtual-machines;

        if ! vagrant status|grep ^$machine|grep running ;
        then 
            echo "[sq-sandbox] Starting up VM $machine...";
            vagrant up $machine;
        fi

        echo -e "\n${PURPLE}======================================================="
        echo -e "[sq-sandbox] Provision of $machine VM"
        echo -e "=======================================================\n"

        vagrant ssh $machine -c "echo && rm -vf /chef/*lock && exit"
        vagrant provision $machine
        echo -e "\nEnd of Provision $machine VM"
        echo -e "=======================================================${INFO}\n"

        echo -e "\n${YELLOW}======================================================="
	echo "[sq-sandbox] Local provision of $machine VM"
        echo -e "=======================================================\n"
	$DIR/sandbox-localprovision.exp $source/devops $machine $password
        echo -e "\nEnd of Provision $machine VM"
        echo -e "=======================================================${INFO}\n"
else
        echo -e "[sq-sandbox] Nothing to update"
        

fi

if [[ ! -z $restart ]];
then
    echo "[sq-sandbox] Restarting virtual machine '$machine'";
    cd /$source/devops/virtual-machines
    vagrant halt $machine;
    vagrant up $machine;
fi


exit;
