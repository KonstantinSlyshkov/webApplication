#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LOCATION_TEXT="Choose your location: \n 1 => Gland\n 2 => Kiev\n 3 => Dnepropetrovsk"

G="\\033[1;32m" #Green
N="\\033[0;39m" #Back to normal

echo -e $LOCATION_TEXT; read location
while [[ $location != "1" && $location != "2" && $location != "3" ]]; do
	echo -e $LOCATION_TEXT; read location
done

# Only for Gland, add linux mirror
if [ $location -eq "1" ]; then
	# TODO Not needed for OS X	
	# Linux Mirror
	$DIR/mirror.sh
	
	echo -e "$G--- Adding base certificate to /etc/ssl/certs$N"
	if [ ! -f /etc/ssl/certs/swissquote-ca.pem ]; then
		if [ ! -d /etc/ssl/certs ]; then
			sudo mkdir -p /etc/ssl/certs
		fi
		sudo cp $DIR/files/swissquote-ca.pem /etc/ssl/certs/swissquote-ca.pem
	fi

	PROXY_DOMAIN="sqtbank"
	PROXY_PROXY="bproxysg.swissquotebank.ch:8080"
	PROXY_NOPROXY="localhost, 127.0.0.*, 10.*, 172.30.*, 172.16.*, 192.168.*, *.swissquote.ch, *.swissquotebank.ch"
fi

if [ $location -eq "2" ]; then
	PROXY_DOMAIN="kiev.luxoft.com"
	PROXY_PROXY="kiev-tmg-rad.kiev.luxoft.com:8080"
	PROXY_NOPROXY="*"
fi

if [ $location -eq "3" ]; then
	PROXY_DOMAIN="kiev.luxoft.com"
	PROXY_PROXY="dp-squid-1.kiev.luxoft.com:3128"
	PROXY_NOPROXY="edevtools3gl.bank.swissquote.ch,172.20.*,172.21.*,172.30.*,172.31.*,217.74.32.*,217.74.40.*,217.74.42.*,192.168.168.*,192.168.169.*,*.luxoft.com,*.dmz.lux,*local.swissquote.ch,dev-tools.info.swissquote.ch,devtools.info.swissquote.ch,192.168.64.20"
fi



if [ ! -f /usr/local/bin/cntlm ]; then
	echo -e "$G--- Installing cntlm$N"
	
	NAME=cntlm
	CNTLM_HOME=/var/run/cntlm

	# Create cntlm user and its homedir
	if ! getent passwd $NAME >/dev/null; then
		sudo adduser --system --home $CNTLM_HOME --shell /bin/sh --disabled-password $NAME
	fi

	if ! [ -d $CNTLM_HOME ]; then
		sudo mkdir -p $CNTLM_HOME
		sudo chmod 755 $CNTLM_HOME
		sudo chown -h -R $NAME $CNTLM_HOME
	fi	
	
	sudo cp $DIR/files/cntlm/cntlm /usr/local/bin/cntlm
	sudo cp $DIR/files/cntlm/cntlm_init /etc/init.d/cntlm
	sudo cp $DIR/files/cntlm/cntlm_default /etc/default/cntlm
	
	sudo cp $DIR/files/cntlm/cntlm.conf /etc/cntlm.conf
	sudo chmod 666 /etc/cntlm.conf	
		
	echo -e "$G---   Proxy credentials$N"
	echo 'Windows Login:'
	read login
	echo 'Windows Password:'
	hashval=`cntlm -H -d $PROXY_DOMAIN -u $login | grep PassNTLMv2 | sed 's/#.*//'`
	echo "Your new Hash has been Generated : $hashval"

	echo -e "$G---   Inserting values in /etc/cntlm.conf$N"
	sudo sed "s/THE_USERNAME_TO_CHANGE/$login/" /etc/cntlm.conf -i
	sudo sed "s/THE_DOMAIN_TO_CHANGE/$PROXY_DOMAIN/" /etc/cntlm.conf -i
	sudo sed "s/#THE_PASS_TO_CHANGE/$hashval/" /etc/cntlm.conf -i
	sudo sed "s/THE_PROXY_TO_CHANGE:8080/$PROXY_PROXY/" /etc/cntlm.conf -i
	sudo sed "s/THE_NOPROXY_TO_CHANGE/$PROXY_NOPROXY/" /etc/cntlm.conf -i

	echo -e "$G---   starting cntlm$N"
	if [ -x "/etc/init.d/cntlm" ]; then
		sudo update-rc.d cntlm defaults >/dev/null
		if [ -x "`which invoke-rc.d 2>/dev/null`" ]; then
			sudo invoke-rc.d cntlm start || exit $?
		else
			sudo /etc/init.d/cntlm start || exit $?
		fi
	fi
else
	echo -e "$G--- cntlm already installed$N"
fi


echo -e "$G--- WGET Proxy$N"
touch ~/.wgetrc
if ! grep -Fq "http_proxy" ~/.wgetrc
then
	echo '#Local Proxy Automatic Configuration' >> ~/.wgetrc
	echo 'http_proxy = http://127.0.0.1:3129/' >> ~/.wgetrc
	echo 'https_proxy = http://127.0.0.1:3129/' >> ~/.wgetrc
	echo 'use_proxy = on' >> ~/.wgetrc
fi


echo -e "$G--- CURL Proxy$N"
touch ~/.curlrc
if ! grep -Fq "proxy" ~/.curlrc
then
	echo '#Local Proxy Automatic Configuration' >> ~/.curlrc
	echo 'proxy = 127.0.0.1:3129' >> ~/.curlrc
fi


echo -e "$G--- GEM Proxy$N"
touch ~/.gemrc
if ! grep -Fq "http_proxy" ~/.gemrc
then
	echo '#Local Proxy Automatic Configuration' >> ~/.gemrc
	echo 'http_proxy: http://127.0.0.1:3129' >> ~/.gemrc
	echo 'https_proxy: http://127.0.0.1:3129' >> ~/.gemrc
fi


#TODO :: not needed for OS X
if [ $location -eq "2" ]; then
	echo -e "$G--- APT Proxy skipped for Kiev$N"
else
	echo -e "$G--- APT Proxy$N"
	sudo touch /etc/apt/apt.conf.d/proxy
	sudo chmod 777 /etc/apt/apt.conf.d/proxy
	if ! grep -Fq "127.0.0.1:3129" /etc/apt/apt.conf.d/proxy
	then
		echo -e '#Local Proxy Automatic Configuration' > /etc/apt/apt.conf.d/proxy
		echo -e 'Acquire::http::Proxy "http://127.0.0.1:3129"; ' >> /etc/apt/apt.conf.d/proxy
		echo -e 'Acquire::https::Proxy "http://127.0.0.1:3129"; ' >> /etc/apt/apt.conf.d/proxy
	fi
fi

