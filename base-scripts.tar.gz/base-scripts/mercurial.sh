#!/usr/bin/env bash

USERNAME=`whoami`
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

G="\\033[1;32m" #Green
B="\\033[1;34m" #Blue
N="\\033[0;39m" #Back to normal


# TODO find a way to install the latest release (ppa)
# TODO Not needed for OS X
if [ ! -f /etc/cntlm.conf ]; then
	echo -e "$G--- Adding PPA for the latest mercurial version$N"
	sudo add-apt-repository ppa:mercurial-ppa/releases
	sudo apt-get update
fi


# TODO Install differently for OS X
echo -e "$G--- Installing Mercurial$N"
sudo apt-get install mercurial -y


echo -e "$G--- Installing HG Certificate$N"
if [ ! -d ~/.cacerts/ ]; then
	mkdir -p ~/.cacerts/
fi

if [ ! -f ~/.cacerts/swissquote-ca.pem ]; then
	cp $DIR/files/swissquote-ca.pem ~/.cacerts/swissquote-ca.pem
fi


echo -e "$G--- Installing default .hgrc file$N"
if [ ! -f ~/.hgrc ]; then
	cp $DIR/files/hgrc ~/.hgrc
	sed "s/USERNAME/$USERNAME/" ~/.hgrc -i
fi


clear
echo -e "$B------------------------------------------------"
echo -e "You can now go to the ~/.hgrc file and enter your username / password"
echo -e $N
