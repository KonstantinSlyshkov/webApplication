#!/usr/bin/env bash

USERNAME=`whoami`

G="\\033[1;32m" #Green
N="\\033[0;39m" #Back to normal


echo -e "$G--- Installing Chef$N"
gem install chef --conservative --no-rdoc


#echo -e "$G--- Installing Vagrant$N"
#gem install vagrant --conservative --no-rdoc


echo -e "$G--- Creating $HOME/workspace dir$N"
mkdir -p $HOME/workspace


echo -e "$G--- Creating symling for /work to $HOME/workspace$N"
if [ ! -L /work ]; then
	sudo ln -s $HOME/workspace /work
fi

echo -e "$G--- Creating $HOME/workspace/foundation dir$N"
mkdir -p $HOME/workspace/foundation
cd $HOME/workspace/foundation


echo -e "$G--- Clone sq-sandbox$N"
if [ ! -d $HOME/workspace/foundation/sq-sandbox/ ]; then
	hg clone --uncompressed https://dev-tools.info.swissquote.ch:444/hg/foundation/sq-sandbox/ -r fox
else
	cd $HOME/workspace/foundation/sq-sandbox
	hg pull --update
fi
