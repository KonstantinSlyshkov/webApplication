#!/usr/bin/env perl
use strict;

my $replace= "http://linuxmirror.info.swissquote.ch/ubuntu/";
my $file=$ARGV[0];
my $sources = '';

{ # must be scoped for the slurp
	open(FILE, $file);
	local $/; # slurps the whole file to a single string
	$sources = <FILE>;
	close (FILE);
}

# the file must be reopened for write as opening it in write mode directly removes the content
open(FILE, ">$file");

# removes newlines in STDIN
chomp(my @mirrors = <STDIN>);

# replaces magical archive.ubuntu.com
$sources =~ s/http:\/\/[a-zA-z]+.archive.ubuntu.com\/ubuntu\//$replace/g;

foreach my $mirror (@mirrors) {
	$sources =~ s/$mirror/$replace/g;
}

print FILE $sources;
close (FILE);
