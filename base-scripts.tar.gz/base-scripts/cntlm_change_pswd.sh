#!/usr/bin/env bash
###################################
# Change domain password for CNTLM
###################################

LOCATION_TEXT="Choose your location: \n 1 => Gland\n 2 => Kiev"

G="\\033[1;32m" #Green
N="\\033[0;39m" #Back to normal

echo -e "$G---   Changing domain password for CNTLM$N"

echo -e $LOCATION_TEXT; 
read location

while [[ $location != "1" && $location != "2" ]]; do
	echo -e $LOCATION_TEXT; read location
done

if [ $location -eq "1" ]; then
	PROXY_DOMAIN="sqtbank"
fi

if [ $location -eq "2" ]; then
	PROXY_DOMAIN="kiev.luxoft.com"
fi

echo -e "$G---   restarting cntlm$N"
if [ -x "/etc/init.d/cntlm" ]; then
	sudo update-rc.d cntlm defaults >/dev/null
	if [ -x "`which invoke-rc.d 2>/dev/null`" ]; then
		sudo invoke-rc.d cntlm restart || exit $?
	else
		sudo /etc/init.d/cntlm restart || exit $?
	fi
fi
