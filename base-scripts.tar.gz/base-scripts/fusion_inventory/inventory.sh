#!/usr/bin/env bash

if [[ $(/usr/bin/id -u) -ne 0 ]]; then
    echo "Not running as root"
    exit
fi

# Vars
######################################################################

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

G="\\033[1;32m" #Green
B="\\033[1;34m" #Blue
N="\\033[0;39m" #Back to normal


# Functions
######################################################################

function e {
	echo -e $1
}

# Install
######################################################################
clear
e $B
e "------------------------------------------------"
e " Swissquote Inventory Script"
e "------------------------------------------------"
e $N

if [ -f /etc/cntlm.conf ]; then
	e "$G--- APT Proxy$N"
	touch /etc/apt/apt.conf.d/proxy
	chmod 777 /etc/apt/apt.conf.d/proxy
	if ! grep -Fq "127.0.0.1:3129" /etc/apt/apt.conf.d/proxy
	then
		e '#Local Proxy Automatic Configuration' > /etc/apt/apt.conf.d/proxy
		e 'Acquire::http::Proxy "http://127.0.0.1:3129"; ' >> /etc/apt/apt.conf.d/proxy
		e 'Acquire::https::Proxy "http://127.0.0.1:3129"; ' >> /etc/apt/apt.conf.d/proxy
	fi

	echo -e "$G--- WGET Proxy$N"
	touch ~/.wgetrc
	if ! grep -Fq "http_proxy" ~/.wgetrc
	then
		e '#Local Proxy Automatic Configuration' >> ~/.wgetrc
		e 'http_proxy = http://127.0.0.1:3129/' >> ~/.wgetrc
		e 'https_proxy = http://127.0.0.1:3129/' >> ~/.wgetrc
		e 'use_proxy = on' >> ~/.wgetrc
	fi
	chown $SUDO_UID:$SUDO_GID ~/.wgetrc
fi

e "$G--- Test For LSB Release$N"
if [ ! -x $(which lsb_release) ] ; then
	e "$G -- Install LSB Release$N"
    apt-get -y install lsb-release || exit $?
fi

DISTRIB=`lsb_release -cs`

e "$G--- Add Fusioninventory to sources$N"
if  ! grep debian.fusioninventory.org /etc/apt/sources.list ; then
	echo "deb http://debian.fusioninventory.org/debian/ $DISTRIB main" >> /etc/apt/sources.list
fi

e "$G--- Add fusioninventory repository key$N"
if ! apt-key finger | grep '1FF3 68E8 0199 1373 1705  B8AF 049E D9B9 4765 572E' ; then
	wget --no-check-certificate -O - 'http://keyserver.ubuntu.com/pks/lookup?op=get&search=0xF88DE0787E57E47B' | apt-key add -  || exit $?
fi

e "$G--- apt-get update$N"
APT_GET=$(apt-get update)	
if echo $APT_GET | grep -q "Err" ; then
	e "apt-get update Failed"
	exit 1
fi

e "$G--- Install fusioninventory-agent$N"
apt-get -y --force-yes install libsocket-getaddrinfo-perl fusioninventory-agent || exit $?

e "$G--- Install /etc/default/fusioninventory-agent$N"
rm /etc/default/fusioninventory-agent
cp $DIR/files/fusioninventory-agent /etc/default/fusioninventory-agent
chmod 644 /etc/default/fusioninventory-agent

e "$G--- Install /etc/fusioninventory/agent.cfg$N"
rm /etc/fusioninventory/agent.cfg
cp $DIR/files/agent.cfg /etc/fusioninventory/agent.cfg
chmod 644 /etc/fusioninventory/agent.cfg

e "$G--- restart fusion-inventory$N"
/etc/init.d/fusioninventory-agent restart

