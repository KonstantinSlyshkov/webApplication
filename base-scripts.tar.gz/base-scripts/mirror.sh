#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
MIRRORS="/usr/share/python-apt/templates/Ubuntu.mirrors"
SOURCES="/etc/apt/sources.list"

G="\\033[1;32m" #Green
N="\\033[0;39m" #Back to normal

echo -e "$G--- Installing New Mirror$N"
if ! grep -Fq "linuxmirror.info.swissquote.ch" $MIRRORS; then
    sudo sed 's/#LOC:CH/#LOC:CH\nhttp:\/\/linuxmirror.info.swissquote.ch\/ubuntu\//' $MIRRORS -i
fi


echo -e "$G--- Applying New Mirror$N"
if [ ! -f $SOURCES.original ]; then
    echo -e "$G---   Backing up original configuration to $SOURCES.original$N"
    sudo cp $SOURCES $SOURCES.original

	echo -e "$G---   Updating software source mirror to linuxmirror.info.swissquote.ch$N"
	cat $MIRRORS | grep tp: | grep -v swissquote | sudo $DIR/mirror.pl $SOURCES
else
	echo "mirrors already changed, do the following command to restore the file:"
	echo "-> sudo rm $SOURCES && sudo mv $SOURCES.original $SOURCES"
fi
