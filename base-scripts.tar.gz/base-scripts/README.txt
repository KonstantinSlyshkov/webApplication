# to create the zip :

zip -r "base-scripts.zip" . -x .DS_Store base-scripts.zip

you need to upload the zip file the wiki on this page :

https://eureka.bank.swissquote.ch/pages/viewpageattachments.action?pageId=6652719