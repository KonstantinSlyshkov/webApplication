#!/usr/bin/env bash

RUBY_VERSION="1.9.3-p286"
PROFILE_FILE="$HOME/.bash_aliases" # TODO Install in an other file for OS X

G="\\033[1;32m" #Green
B="\\033[1;34m" #Blue
N="\\033[0;39m" #Back to normal


# TODO Install differently for OS X
echo -e "$G--- Installing Git$N"
sudo apt-get install git-core -y


## Add another configuration for this
if [ -f /etc/cntlm.conf ]; then
	echo -e "$G--- Configuring GIT for the proxy$N"
	git config --global http.proxy http://127.0.0.1:3129
	git config --global http.sslVerify false
fi


# TODO Install differently for OS X
echo -e "$G--- Installing Ruby Dependencies$N"
sudo apt-get install zlib1g-dev openssl libssl-dev libreadline-dev libxslt-dev libxml2-dev -y


echo -e "$G--- Installing RBENV$N"
cd ~
if [ ! -f ~/.rbenv/README.md ]; then
	
	# if the readme doesn't exist and .rbenv folder exists : remove it
	if [ ! -d ~/.rbenv ]; then
		rm -rf ~/.rbenv
	fi
	
	git clone http://github.com/sstephenson/rbenv.git .rbenv || exit $?
fi


echo -e "$G--- Configuring PATH for rbenv$N"
touch $PROFILE_FILE
if ! grep -Fq "rbenv" $PROFILE_FILE
then
	echo '#rbenv configuration' >> $PROFILE_FILE
	echo 'export PATH="$HOME/.rbenv/bin:$PATH"' >> $PROFILE_FILE
	echo 'eval "$(rbenv init -)"' >> $PROFILE_FILE
fi
export PATH="$HOME/.rbenv/bin:$PATH"
eval "$(rbenv init -)"


echo -e "$G--- Installing rbenv plugins$N"
if [ ! -d ~/.rbenv/plugins/ ]; then
	mkdir -p ~/.rbenv/plugins
fi
cd ~/.rbenv/plugins


echo -e "$G---   ruby-build$N"
if [ ! -d ~/.rbenv/plugins/ruby-build/ ]; then
	git clone http://github.com/sstephenson/ruby-build.git
fi


echo -e "$G---   rbenv-sudo$N"
if [ ! -d ~/.rbenv/plugins/rbenv-sudo/ ]; then
	git clone http://github.com/dcarley/rbenv-sudo.git
fi


echo -e "$G--- Installing Ruby $RUBY_VERSION$N"
if [ ! -d ~/.rbenv/versions/$RUBY_VERSION ]; then
	rbenv install $RUBY_VERSION
	rbenv global $RUBY_VERSION
	rbenv rehash
fi

echo -e "$G--- Test Ruby$N"
ruby --version || exit $?
